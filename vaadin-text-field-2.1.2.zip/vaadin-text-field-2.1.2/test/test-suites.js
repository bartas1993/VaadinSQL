window.VaadinTextFieldSuites = [
  'text-field.html',
  'text-area.html',
  'password-field.html',
  'validation.html',
  'accessibility.html'
];
